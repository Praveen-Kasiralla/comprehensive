package uistore;

import org.openqa.selenium.By;

public class FooterUi {
	public static By product = By.cssSelector("a[class='CoveoResultLink']");
	//nobroker
	public static By emiCalculator = By.cssSelector("[href='/prophub/home-loan/emi-calculator/']");
	public static By aboutUs = By.cssSelector(".nb__3N2G9.nb__2WC_s");
}
