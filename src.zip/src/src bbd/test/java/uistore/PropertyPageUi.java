package uistore;

import org.openqa.selenium.By;

public class PropertyPageUi {

	public static By photos = By.cssSelector("[class='nb__baS10']");
	public static By photoLightbox = By.cssSelector("[class='nb-lightbox-content']");
}
