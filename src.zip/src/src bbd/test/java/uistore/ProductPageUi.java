package uistore;

import org.openqa.selenium.By;

public class ProductPageUi {

	public static By searchProduct = By.cssSelector("a[class='CoveoResultLink']");
	public static By series3000i = By.xpath("//*[text()=' Series 3000i ']");
}
