package uistore;

import org.openqa.selenium.By;

public class WalletPageUi {

	public static By joinClub = By.cssSelector(".joinclub-btn");
}
